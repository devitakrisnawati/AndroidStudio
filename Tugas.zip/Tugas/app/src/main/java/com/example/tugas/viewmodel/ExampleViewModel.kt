package com.example.tugas.viewmodel

import androidx.lifecycle.ViewModel

class ExampleViewModel : ViewModel() {
    val number = 0

    fun addNumber(){
        number++
    }
}