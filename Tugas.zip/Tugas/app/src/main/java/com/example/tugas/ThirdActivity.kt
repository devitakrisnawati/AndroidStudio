package com.example.tugas

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class ThirdActivity : AppCompatActivity(),BottomNavigationView.OnNavigationItemSelectedListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third)

        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomNavigationView)

        supportActionBar?.apply {
            title = "Devita Krisnawati Simarmata"
            subtitle = resources.getString(R.string.app_name)
        }

        laodFragment(HomeFragment2())

        bottomNavigationView.setOnNavigationItemReselectedListener(this)
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when(item.itemId) {
            R.id.home_menu -> laodFragment(HomeFragment2())
            R.id.search -> laodFragment(SearchFragment())
            R.id.about -> laodFragment(AboutFragment())
        }
        return true
    }

    private fun laodFragment(fragment: Fragment) {
        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.frameLayout,fragment)
        transaction.commit()

    }
}

private fun BottomNavigationView.setOnNavigationItemReselectedListener(thirdActivity: ThirdActivity) {

}
