package com.example.tugas

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import com.example.tugas.databinding.ActivityFourthBinding
import com.example.tugas.viewmodel.ExampleViewModel

class FourthActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFourthBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFourthBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val viewModel = ViewModelProvider(this@FourthActivity)[ExampleViewModel::class.java]

        binding.tvNumber.text = viewModel.number.toString()

        binding.btnAdd.setOnClickListener {
            viewModel.addNumber()
            binding.tvNumber.text = viewModel.number.toString()
        }
    }
}